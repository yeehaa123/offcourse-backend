var db_out = require("./target/main");
exports.handler = db_out.app.core.handler;
